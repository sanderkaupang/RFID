#include "afxwin.h"
#if !defined(AFX_DLG5_H__A6EA0B4C_7015_4601_B2C2_4D44E7E2B394__INCLUDED_)
#define AFX_DLG5_H__A6EA0B4C_7015_4601_B2C2_4D44E7E2B394__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dlg5.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg5 dialog

class CDlg5 : public CDialog
{
// Construction
public:
	CDlg5(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg5)
	enum { IDD = IDD_DIALOG5 };
	CString	m_V_editAPP;
	CString	m_V_editDES16Key;
	CString	m_V_editDESNew16Key;
	CString	m_V_editNewAPPKeySetting;
	CString	m_V_editNewFile;
	CString	m_V_editFiledata;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg5)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg5)
	afx_msg void OnButton1();
	afx_msg void OnButton9();
	afx_msg void OnButton2();
	afx_msg void OnButton3();
	afx_msg void OnButton10();
	afx_msg void OnButton4();
	afx_msg void OnButton6();
	afx_msg void OnButton7();
	afx_msg void OnButton8();
	afx_msg void OnButton22();
	afx_msg void OnButton23();
	afx_msg void OnButton19();
	afx_msg void OnButton20();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton5();
	CString m_V_editKeyNo;
	CString m_V_editNewKeySetting;
	afx_msg void OnBnClickedButton13();
	afx_msg void OnBnClickedButton11();
	CString m_V_editNewAppKeyNo;
	afx_msg void OnBnClickedButton14();
	afx_msg void OnBnClickedButton15();
	afx_msg void OnBnClickedButton16();
	CString m_V_editNewComSet;
	CString m_V_editNewAcessRight;
	CString m_V_editNewFileSize;
	afx_msg void OnBnClickedButton17();
	CString m_V_editLowerLimit;
	CString m_V_editUpperLimit;
	CString m_V_editFileValue;
	afx_msg void OnBnClickedButton18();
	CButton m_V_checkLimitCredit;
	virtual BOOL OnInitDialog();
	CString m_V_editFileOffset;
	CString m_V_editFiledatalen;
	afx_msg void OnBnClickedButton21();
	afx_msg void OnBnClickedButton30();
	afx_msg void OnBnClickedButton31();
	afx_msg void OnBnClickedButton32();
	afx_msg void OnBnClickedButton35();
	afx_msg void OnBnClickedButton36();
	CString m_V_editRecordsNum;
	afx_msg void OnBnClickedButton37();
	afx_msg void OnBnClickedButton38();
	afx_msg void OnBnClickedButton39();
	afx_msg void OnBnClickedButton40();
	afx_msg void OnBnClickedButton41();
	afx_msg void OnBnClickedButton12();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG5_H__A6EA0B4C_7015_4601_B2C2_4D44E7E2B394__INCLUDED_)
