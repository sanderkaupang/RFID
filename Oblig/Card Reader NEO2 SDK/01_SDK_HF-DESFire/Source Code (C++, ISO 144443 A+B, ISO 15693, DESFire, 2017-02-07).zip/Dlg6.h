#pragma once
#include "afxwin.h"


// CDlg6 �Ի���

class CDlg6 : public CDialog
{
	DECLARE_DYNAMIC(CDlg6)

public:
	CDlg6(CWnd* pParent = NULL);   // ��׼���캯��
	virtual ~CDlg6();

// �Ի�������
	enum { IDD = IDD_DIALOG6 };

protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV ֧��

	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton9();
	CString m_V_editSAMcardsn;
	CString m_V_editSAMfactor1;
	CString m_V_editSAMfactor2;
	afx_msg void OnBnClickedButton1();
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton30();
	afx_msg void OnBnClickedButton31();
	afx_msg void OnBnClickedButton32();
	virtual BOOL OnInitDialog();
	BOOL m_V_checknewold;
	CButton m_V_checkoldnew;
	CString m_V_editST00data;
	CString m_V_editST01data;
	CString m_V_editST02data;
	CString m_V_editST03data;
	CString m_V_editST04data;
	CString m_V_editST05data;
	CString m_V_editST06data;
	CString m_V_editST07data;
	CString m_V_editST11data;
	CString m_V_editST12data;
	CString m_V_editST15data;
	afx_msg void OnBnClickedButton33();
	afx_msg void OnBnClickedButton34();
};
