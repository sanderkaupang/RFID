// Dlg6.cpp : ʵ���ļ�
//

#include <windows.h>
#include "stdafx.h"
#include "COMM.h"
#include "Dlg6.h"
#include "Public.h"
#include "MYDLL.h"





// CDlg6 �Ի���

IMPLEMENT_DYNAMIC(CDlg6, CDialog)

CDlg6::CDlg6(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg6::IDD, pParent)
{

}

CDlg6::~CDlg6()
{
}

void CDlg6::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
}


BEGIN_MESSAGE_MAP(CDlg6, CDialog)

END_MESSAGE_MAP()



BOOL CDlg6::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_V_checkoldnew.SetCheck(true);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

