// Dlg2.cpp : implementation file
//
#include <windows.h>
#include "stdafx.h"
#include "COMM.h"
#include "Dlg2.h"
#include "Public.h"
#include "MYDLL.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


unsigned char getsn[10];
/////////////////////////////////////////////////////////////////////////////
// CDlg2 dialog


CDlg2::CDlg2(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg2::IDD, pParent)
	, m_V_editChannalA(_T("0084000008"))
	, m_V_editKey(_T("FFFFFFFFFFFF"))
	, m_V_editNewKey(_T("112233445566"))
	, m_V_edit16data(_T("00112233445566778899AABBCCDDEEFF"))
	
	, m_V_editInitValue(_T("64000000"))
	, m_V_editOperValue(_T("01000000"))
	, m_V_editTansferCmd(_T("0A000084000008"))
{
	//{{AFX_DATA_INIT(CDlg2)
	m_V_edit16UCkey = _T("49454D4B41455242214E4143554F5946");
	m_V_edit16UCNewkey = _T("00112233445566778899AABBCCDDEEFF");
	m_V_edit4UCdata = _T("01020304");
	//}}AFX_DATA_INIT
}


void CDlg2::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg2)
	DDX_Control(pDX, IDC_COMBO5, IDC_cobULOperBlock);
	DDX_Text(pDX, IDC_EDIT9, m_V_edit16UCkey);
	DDX_Text(pDX, IDC_EDIT10, m_V_edit16UCNewkey);
	DDX_Text(pDX, IDC_EDIT11, m_V_edit4UCdata);
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COMBO1, m_C_cobInlistMode);
	DDX_Text(pDX, IDC_EDIT3, m_V_editChannalA);
	DDX_Control(pDX, IDC_CHECK2, m_V_checkRATS);
	DDX_Control(pDX, IDC_COMBO2, m_C_cobKeyType);
	DDX_Control(pDX, IDC_COMBO4, IDC_cobOperBlock);
	DDX_Control(pDX, IDC_COMBO3, IDC_cobBackupBlock);
	DDX_Text(pDX, IDC_EDIT2, m_V_editKey);
	DDX_Text(pDX, IDC_EDIT7, m_V_editNewKey);
	DDX_Text(pDX, IDC_EDIT5, m_V_edit16data);
	DDX_Text(pDX, IDC_EDIT8, m_V_editInitValue);
	DDX_Text(pDX, IDC_EDIT6, m_V_editOperValue);
	DDV_MaxChars(pDX, m_V_editOperValue, 8);
	DDV_MaxChars(pDX, m_V_editInitValue, 8);
	DDV_MaxChars(pDX, m_V_edit16data, 32);
	DDV_MaxChars(pDX, m_V_editNewKey, 12);
	DDV_MaxChars(pDX, m_V_editKey, 12);
	DDV_MaxChars(pDX, m_V_editChannalA, 1024);
	DDX_Text(pDX, IDC_EDIT4, m_V_editTansferCmd);
	DDV_MaxChars(pDX, m_V_editTansferCmd, 1024);
	DDX_Control(pDX, IDC_COMBO6, m_C_cobPersonalize);
}


BEGIN_MESSAGE_MAP(CDlg2, CDialog)
	//{{AFX_MSG_MAP(CDlg2)
	ON_BN_CLICKED(IDC_BUTTON21, OnButton21)
	ON_BN_CLICKED(IDC_BUTTON20, OnButton20)
	ON_BN_CLICKED(IDC_BUTTON19, OnButton19)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON5, OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON7, OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON16, OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON9, OnBnClickedButton9)
	ON_BN_CLICKED(IDC_BUTTON8, OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON17, OnBnClickedButton17)
	ON_BN_CLICKED(IDC_BUTTON10, OnBnClickedButton10)
	ON_BN_CLICKED(IDC_BUTTON13, OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON12, OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON11, OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON14, OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON6, &CDlg2::OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON30, &CDlg2::OnBnClickedButton30)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg2 message handlers

void CDlg2::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	ret = PiccReset(100);//ms
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

BOOL CDlg2::OnInitDialog()
{
	CDialog::OnInitDialog();

	unsigned char i;
	CString strTmp;

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_C_cobInlistMode.ResetContent();									//Ϊ������������ֵ
	
	m_C_cobInlistMode.InsertString(0,"ISO 14443 A Card");
	m_C_cobInlistMode.InsertString(1,"ISO 14443 B Card");
	m_C_cobInlistMode.InsertString(2,"SONY FeliCa Card");
	m_C_cobInlistMode.InsertString(3,"Chinese ID Card");
	m_C_cobInlistMode.InsertString(4,"Chinese 8BytesID");
	m_C_cobInlistMode.SetCurSel(0);


	
	m_C_cobPersonalize.ResetContent();									//Ϊ������������ֵ
	
	m_C_cobPersonalize.InsertString(0,"7Byte UID");
	m_C_cobPersonalize.InsertString(1,"7Byte UID and Shortcut");
	m_C_cobPersonalize.InsertString(2,"4Byte Random ID");
	m_C_cobPersonalize.InsertString(3,"4Byte Non Unique ID");
	m_C_cobPersonalize.SetCurSel(3);

	//m_V_checkRATS.SetCheck(true);


	//
	IDC_cobOperBlock.ResetContent();
	IDC_cobBackupBlock.ResetContent();
	for (i = 0;i < 64;i++)
	{
		strTmp.Format("%02X",i);
		IDC_cobOperBlock.InsertString(i,strTmp);
		IDC_cobBackupBlock.InsertString(i,strTmp);
		IDC_cobULOperBlock.InsertString(i,strTmp);
	}
	IDC_cobOperBlock.SetCurSel(5);
	IDC_cobULOperBlock.SetCurSel(5);
	IDC_cobBackupBlock.SetCurSel(6);

	m_C_cobKeyType.ResetContent();
	m_C_cobKeyType.InsertString(0,"KEYA");
	m_C_cobKeyType.InsertString(1,"KEYB");
	m_C_cobKeyType.SetCurSel(0);

	//

	//UpdateData(false);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlg2::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	ret = PiccReset(0);//0 ms is RST and close
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton3()
{
	// TODO: Add extra validation here
	int ret;
	unsigned char tempbuff[2048];
	unsigned char kind,reset,rats;
	CString neirong;//����һ���ַ����ı���
	CString temp,temp1;
	//

	kind = m_C_cobInlistMode.GetCurSel();

	reset = IsDlgButtonChecked(IDC_CHECK1);

	

	if(reset)
	{
		PiccReset(10);//ms
	}	

	if(kind==0)
	{
		rats = IsDlgButtonChecked(IDC_CHECK2);
		if(rats)
		{
			PiccAutoRATS(1);
		}
		else
		{
			PiccAutoRATS(0);
		}
		//
		ret = PiccActivateA(0,0x52,&tempbuff[0],&tempbuff[2],&tempbuff[3],&tempbuff[4]) ;
		//
		if(ret==OK)
		{
			ret = SetBuzzer(0x03,0x01);
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nATQ:";
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[0]);
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[1]);
			temp+=temp1;
			temp+="\r\n";
			//
			temp1.Format(" %02X",tempbuff[2]);
			temp+="SAK:";
			temp+=temp1;
			temp+="\r\n";
			//
			temp+="UID:";

			//temp.Format("\r\n-----------------------------------------------------\r\nSuccessed!\r\n\r\nUID Length:%s \r\nCard ID:",CPublic::DtoOX(tempbuff[3]));
			for(int i=0;i < tempbuff[3];i++)
			{
				temp1.Format(" %02X",tempbuff[4+i]);
				temp+=temp1;
			}
			//save uid for authenticate
			if(tempbuff[3]==4)
			{
				memcpy(getsn,&tempbuff[4],4);

			}
			else
			{
				memcpy(getsn,&tempbuff[7],4);
			}
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
			temp1 = "\r\nError Code:";
			temp+=temp1;
			temp1.Format(" %02X",ret);
			temp+=temp1;
		}
	}
	else if(kind==1)
	{
		ret = PiccActivateB(0,0,0,0,&tempbuff[0],&tempbuff[1]);
		//
		if(ret==OK)
		{
			ret = SetBuzzer(0x03,0x01);
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nUID & ATR:";
			temp+=temp1;
			//temp.Format("\r\n-----------------------------------------------------\r\nSuccessed!\r\n\r\nUID Length:%s \r\nCard ID:",CPublic::DtoOX(tempbuff[3]));
			for(int i=0;i < tempbuff[0];i++)
			{
				temp1.Format(" %02X",tempbuff[1+i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n-----------------------------------------------------\r\nFail!";
			temp1 = "\r\nError Code:";
			temp+=temp1;
			temp1.Format(" %02X",ret);
			temp+=temp1;
		}
	}
	else if(kind==2)
	{
		ret = PiccActivateC(0,1,&tempbuff[0],&tempbuff[1]);
		//
		if(ret==OK)
		{
			ret = SetBuzzer(0x03,0x01);
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nUID & ATR:";
			temp+=temp1;
			//temp.Format("\r\n-----------------------------------------------------\r\nSuccessed!\r\n\r\nUID Length:%s \r\nCard ID:",CPublic::DtoOX(tempbuff[3]));
			for(int i=0;i < tempbuff[0];i++)
			{
				temp1.Format(" %02X",tempbuff[1+i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n-----------------------------------------------------\r\nFail!";
			temp1 = "\r\nError Code:";
			temp+=temp1;
			temp1.Format(" %02X",ret);
			temp+=temp1;
		}
	}
	else if(kind==3)
	{
		ret = PiccActivateB(0,8,0,0,&tempbuff[0],&tempbuff[1]);
		//
		if(ret==OK)
		{
			ret = SetBuzzer(0x03,0x01);
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nUID & ATR:";
			temp+=temp1;
			//temp.Format("\r\n-----------------------------------------------------\r\nSuccessed!\r\n\r\nUID Length:%s \r\nCard ID:",CPublic::DtoOX(tempbuff[3]));
			for(int i=0;i < tempbuff[0];i++)
			{
				temp1.Format(" %02X",tempbuff[1+i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n-----------------------------------------------------\r\nFail!";
			temp1 = "\r\nError Code:";
			temp+=temp1;
			temp1.Format(" %02X",ret);
			temp+=temp1;
		}
	}
	else if(kind==4)
	{
		ret = PiccActivateCID(10,&tempbuff[1]);
		//
		if(ret==OK)
		{
			ret = SetBuzzer(0x03,0x01);
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\n8Bytes UID:";
			temp+=temp1;
			for(int i=0;i < 8;i++)
			{
				temp1.Format(" %02X",tempbuff[1+i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n-----------------------------------------------------\r\nFail!";
			temp1 = "\r\nError Code:";
			temp+=temp1;
			temp1.Format(" %02X",ret);
			temp+=temp1;
		}
	}
	else
	{
		ret = 1;
		temp = "\r\n^----------------------------------------------------\r\nNot Support!";
	}
	

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	ret = PiccRequestATS(0,&tempbuff[0],&tempbuff[1]);//0 ms is RST and close
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nATS:";
		temp+=temp1;
		for(int i=0;i < tempbuff[0];i++)
		{
			temp1.Format(" %02X",tempbuff[1+i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton5()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned int strSize2;
	unsigned char buffer[2048];
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT3))->GetWindowText(m_V_editChannalA);
	strcpy((char *)buffer,m_V_editChannalA);
	CPublic::OXStrtoD(strSize1,buffer);
	//
	ret = PiccTPCL(strSize1,&buffer[0],&strSize2,&tempbuff[0]);//0 ms is RST and close
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nRec:";
		temp+=temp1;
		for(unsigned int i=0;i < strSize2;i++)
		{
			temp1.Format(" %02X",tempbuff[i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton7() //authenticate
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char auth_mode,addr;
	unsigned char key[24];
	int ret;
	int strSize;
	CString neirong,temp,temp1;
	//
	auth_mode = (m_C_cobKeyType.GetCurSel()|0x60);
	//
	addr = IDC_cobOperBlock.GetCurSel();
	//
	(GetDlgItem(IDC_EDIT2))->GetWindowText(m_V_editKey);
	strcpy((char *)key,m_V_editKey);
	CPublic::OXStrtoD(strSize,key);
	//
	if (6 != strSize)
	{
		temp = "\r\n^----------------------------------------------------\r\nKey length must be 6Bytes!";
	}
	else
	{
		ret = PiccAuthKey( auth_mode,addr,getsn,key) ;
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}

	}
	//
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton16()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
}


void CDlg2::OnBnClickedButton9() //read
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	CString neirong,temp,temp1,carddata;
	//
	addr = IDC_cobOperBlock.GetCurSel();
	//
	ret = PiccRead(addr, pBuf);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nData:";
		temp+=temp1;
		carddata = "";
		for(int i=0;i < 16;i++)
		{
			temp1.Format(" %02X",pBuf[i]);
			temp+=temp1;
			carddata+=temp1;
		}
		(GetDlgItem(IDC_EDIT5))->SetWindowText(carddata);
	}
	else
	{
		carddata = "";
		(GetDlgItem(IDC_EDIT5))->SetWindowText(carddata);
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton8() //write
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	int strSize;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobOperBlock.GetCurSel();
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_edit16data);
	strcpy((char *)pBuf,m_V_edit16data);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	if (16 != strSize)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must be 16Bytes!";
	}
	else
	{
		//
		ret = PiccWrite(addr,pBuf);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton17()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	int strSize;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobULOperBlock.GetCurSel();
	(GetDlgItem(IDC_EDIT11))->GetWindowText(m_V_edit4UCdata);
	strcpy((char *)pBuf,m_V_edit4UCdata);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	if (4 != strSize)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must be 4Bytes!";
	}
	else
	{
		//
		ret = PiccULWrite(addr,pBuf);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton10() //initiate value
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	int strSize;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobOperBlock.GetCurSel();
	(GetDlgItem(IDC_EDIT8))->GetWindowText(m_V_editInitValue);
	strcpy((char *)pBuf,m_V_editInitValue);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	if (4 != strSize)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must be 4Bytes!";
	}
	else
	{
		//
		ret = PiccInitVL(addr,pBuf);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton13() //read value
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobOperBlock.GetCurSel();
	//
	ret = PiccReadValue(addr, pBuf);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nValue:";
		temp+=temp1;
		for(int i=0;i < 4;i++)
		{
			temp1.Format(" %02X",pBuf[i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton12()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	/*
	0xC0 --��
	0xC1 --��
	*/
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	int strSize;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobOperBlock.GetCurSel();
	(GetDlgItem(IDC_EDIT6))->GetWindowText(m_V_editOperValue);
	strcpy((char *)pBuf,m_V_editOperValue);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	if (4 != strSize)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must be 4Bytes!";
	}
	else
	{
		//
		ret = PiccValueOper(0xC0,addr,pBuf,addr);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton11()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	/*
	0xC0 --��
	0xC1 --��
	*/
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	int strSize;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobOperBlock.GetCurSel();
	(GetDlgItem(IDC_EDIT6))->GetWindowText(m_V_editOperValue);
	strcpy((char *)pBuf,m_V_editOperValue);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	if (4 != strSize)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must be 4Bytes!";
	}
	else
	{
		//
		ret = PiccValueOper(0xC1,addr,pBuf,addr);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton14()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,addrto;
	int ret;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobOperBlock.GetCurSel();
	addrto = IDC_cobBackupBlock.GetCurSel();
	//
	ret = PiccBackup(addr, addrto);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnButton21() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	CString neirong,temp,temp1;
	//
	addr = IDC_cobULOperBlock.GetCurSel();
	//
	ret = PiccRead(addr, pBuf);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nData:";
		temp+=temp1;
		for(int i=0;i < 16;i++)
		{
			temp1.Format(" %02X",pBuf[i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg2::OnButton20() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char buffer[2048];
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT9))->GetWindowText(m_V_edit16UCkey);
	strcpy((char *)buffer,m_V_edit16UCkey);
	CPublic::OXStrtoD(strSize1,buffer);
	//
	ret = PiccULAuth(&buffer[0]);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg2::OnButton19() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char buffer[2048];
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT10))->GetWindowText(m_V_edit16UCNewkey);
	strcpy((char *)buffer,m_V_edit16UCNewkey);
	CPublic::OXStrtoD(strSize1,buffer);
	//
	ret = PiccULSetKey(&buffer[0]);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);		
}

void CDlg2::OnBnClickedButton6()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned int strSize2;
	unsigned char buffer[2048];
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT4))->GetWindowText(m_V_editTansferCmd);
	strcpy((char *)buffer,m_V_editTansferCmd);
	CPublic::OXStrtoD(strSize1,buffer);
	//
	ret = PiccTANSf(strSize1,&buffer[0],&strSize2,&tempbuff[0]);//0 ms is RST and close
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nRec:";
		temp+=temp1;
		for(unsigned int i=0;i < strSize2;i++)
		{
			temp1.Format(" %02X",tempbuff[i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg2::OnBnClickedButton30()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char kind;
	int ret;
	CString neirong,temp,temp1,carddata;
	//
	kind = m_C_cobPersonalize.GetCurSel();
	if(kind==0x00)
	{
		kind = 0x00;
	}
	else if(kind==0x01)
	{
		kind = 0x40;
	}
	else if(kind==0x02)
	{
		kind = 0x20;
	}
	else 
	{
		kind = 0x60;
	}
	//
	ret = PiccPersonalize(kind);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}
