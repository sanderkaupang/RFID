#include "afxwin.h"
#if !defined(AFX_DLG2_H__B00A2511_B51B_49D6_A856_F6282D630D6E__INCLUDED_)
#define AFX_DLG2_H__B00A2511_B51B_49D6_A856_F6282D630D6E__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dlg2.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg2 dialog

class CDlg2 : public CDialog
{
// Construction
public:
	CDlg2(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg2)
	enum { IDD = IDD_DIALOG2 };
	CComboBox	IDC_cobULOperBlock;
	CString	m_V_edit16UCkey;
	CString	m_V_edit16UCNewkey;
	CString	m_V_edit4UCdata;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg2)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg2)
	afx_msg void OnButton21();
	afx_msg void OnButton20();
	afx_msg void OnButton19();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	virtual BOOL OnInitDialog();
	CComboBox m_C_cobInlistMode;
	afx_msg void OnBnClickedButton2();
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton5();
	CString m_V_editChannalA;
	CButton m_V_checkRATS;
	afx_msg void OnBnClickedButton7();
	afx_msg void OnBnClickedButton16();
	CComboBox m_C_cobKeyType;
	CComboBox IDC_cobOperBlock;
	CComboBox IDC_cobBackupBlock;
	CString m_V_editKey;
	CString m_V_editNewKey;
	CString m_V_edit16data;
	afx_msg void OnBnClickedButton9();
	afx_msg void OnBnClickedButton8();
	afx_msg void OnBnClickedButton17();
	CString m_V_editInitValue;
	CString m_V_editOperValue;
	afx_msg void OnBnClickedButton10();
	afx_msg void OnBnClickedButton13();
	afx_msg void OnBnClickedButton12();
	afx_msg void OnBnClickedButton11();
	afx_msg void OnBnClickedButton14();
	CString m_V_editTansferCmd;
	afx_msg void OnBnClickedButton6();
	CComboBox m_C_cobPersonalize;
	afx_msg void OnBnClickedButton30();
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG2_H__B00A2511_B51B_49D6_A856_F6282D630D6E__INCLUDED_)
