#include "afxwin.h"
#if !defined(AFX_DLG4_H__8AB9762A_1851_4751_A45F_8F3034BFE9A6__INCLUDED_)
#define AFX_DLG4_H__8AB9762A_1851_4751_A45F_8F3034BFE9A6__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dlg4.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg4 dialog

class CDlg4 : public CDialog
{
// Construction
public:
	CDlg4(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg4)
	enum { IDD = IDD_DIALOG4 };
	CComboBox	m_operBlock15693;
	CString	m_V_editflag;
	CString	m_V_edit4data;
	CString	m_V_editAFI;
	CString	m_V_editDSFID;
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg4)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg4)
	afx_msg void OnInventory();
	afx_msg void OnClear();
	afx_msg void OnReadBlock15693();
	virtual BOOL OnInitDialog();
	afx_msg void OnWriteblock15693();
	afx_msg void OnLockBlock();
	afx_msg void OnWriteAFI();
	afx_msg void OnLockAFI();
	afx_msg void OnWriteDSFID();
	afx_msg void OnLockDSFID();
	afx_msg void OnGetSysInfor();
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton19();
	CString m_V_edit15693uid;
	afx_msg void OnBnClickedButton20();
	CButton m_V_checkTimeSlot;
	CComboBox m_muchBlock15693;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG4_H__8AB9762A_1851_4751_A45F_8F3034BFE9A6__INCLUDED_)
