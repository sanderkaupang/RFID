// Dlg5.cpp : implementation file
//
#include <windows.h>
#include "stdafx.h"
#include "COMM.h"
#include "Dlg5.h"
#include "Public.h"
#include "MYDLL.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


/////////////////////////////////////////////////////////////////////////////
// CDlg5 dialog


CDlg5::CDlg5(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg5::IDD, pParent)
	, m_V_editKeyNo(_T("00"))
	, m_V_editNewKeySetting(_T("09"))
	, m_V_editNewAppKeyNo(_T("04"))
	, m_V_editNewComSet(_T("00"))
	, m_V_editNewAcessRight(_T("EE EE"))
	, m_V_editNewFileSize(_T("00 01"))
	, m_V_editLowerLimit(_T("00 00 00 00"))
	, m_V_editUpperLimit(_T("FF FF 00 00"))
	, m_V_editFileValue(_T("00 01 00 00"))
	, m_V_editFileOffset(_T("00 00"))
	, m_V_editFiledatalen(_T("05 00"))
	, m_V_editRecordsNum(_T("04 00"))
{
	//{{AFX_DATA_INIT(CDlg5)
	m_V_editAPP = _T("00 00 00");
	m_V_editDES16Key = _T("00000000000000000000000000000000");
	m_V_editDESNew16Key = _T("00112233445566778899AABBCCDDEEFF");
	m_V_editNewAPPKeySetting = _T("09");
	m_V_editNewFile = _T("01");
	m_V_editFiledata = _T("0102030405");
	//}}AFX_DATA_INIT
}


void CDlg5::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg5)
	DDX_Text(pDX, IDC_EDIT11, m_V_editAPP);
	DDX_Text(pDX, IDC_EDIT15, m_V_editDES16Key);
	DDX_Text(pDX, IDC_EDIT16, m_V_editDESNew16Key);
	DDX_Text(pDX, IDC_EDIT12, m_V_editNewAPPKeySetting);
	DDX_Text(pDX, IDC_EDIT13, m_V_editNewFile);
	DDX_Text(pDX, IDC_EDIT14, m_V_editFiledata);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_EDIT2, m_V_editKeyNo);
	DDX_Text(pDX, IDC_EDIT3, m_V_editNewKeySetting);
	DDX_Text(pDX, IDC_EDIT4, m_V_editNewAppKeyNo);
	DDX_Text(pDX, IDC_EDIT7, m_V_editNewComSet);
	DDX_Text(pDX, IDC_EDIT8, m_V_editNewAcessRight);
	DDX_Text(pDX, IDC_EDIT9, m_V_editNewFileSize);
	DDX_Text(pDX, IDC_EDIT10, m_V_editLowerLimit);
	DDX_Text(pDX, IDC_EDIT22, m_V_editUpperLimit);
	DDX_Text(pDX, IDC_EDIT23, m_V_editFileValue);
	DDX_Control(pDX, IDC_CHECK1, m_V_checkLimitCredit);
	DDX_Text(pDX, IDC_EDIT24, m_V_editFileOffset);
	DDX_Text(pDX, IDC_EDIT25, m_V_editFiledatalen);
	DDX_Text(pDX, IDC_EDIT26, m_V_editRecordsNum);
}


BEGIN_MESSAGE_MAP(CDlg5, CDialog)
	//{{AFX_MSG_MAP(CDlg5)
	ON_BN_CLICKED(IDC_BUTTON1, OnButton1)
	ON_BN_CLICKED(IDC_BUTTON9, OnButton9)
	ON_BN_CLICKED(IDC_BUTTON2, OnButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnButton3)
	ON_BN_CLICKED(IDC_BUTTON10, OnButton10)
	ON_BN_CLICKED(IDC_BUTTON4, OnButton4)
	ON_BN_CLICKED(IDC_BUTTON6, OnButton6)
	ON_BN_CLICKED(IDC_BUTTON7, OnButton7)
	ON_BN_CLICKED(IDC_BUTTON8, OnButton8)
	ON_BN_CLICKED(IDC_BUTTON22, OnButton22)
	ON_BN_CLICKED(IDC_BUTTON23, OnButton23)
	ON_BN_CLICKED(IDC_BUTTON19, OnButton19)
	ON_BN_CLICKED(IDC_BUTTON20, OnButton20)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON5, &CDlg5::OnBnClickedButton5)
	ON_BN_CLICKED(IDC_BUTTON13, &CDlg5::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON11, &CDlg5::OnBnClickedButton11)
	ON_BN_CLICKED(IDC_BUTTON14, &CDlg5::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON15, &CDlg5::OnBnClickedButton15)
	ON_BN_CLICKED(IDC_BUTTON16, &CDlg5::OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON17, &CDlg5::OnBnClickedButton17)
	ON_BN_CLICKED(IDC_BUTTON18, &CDlg5::OnBnClickedButton18)
	ON_BN_CLICKED(IDC_BUTTON21, &CDlg5::OnBnClickedButton21)
	ON_BN_CLICKED(IDC_BUTTON30, &CDlg5::OnBnClickedButton30)
	ON_BN_CLICKED(IDC_BUTTON31, &CDlg5::OnBnClickedButton31)
	ON_BN_CLICKED(IDC_BUTTON32, &CDlg5::OnBnClickedButton32)
	ON_BN_CLICKED(IDC_BUTTON35, &CDlg5::OnBnClickedButton35)
	ON_BN_CLICKED(IDC_BUTTON36, &CDlg5::OnBnClickedButton36)
	ON_BN_CLICKED(IDC_BUTTON37, &CDlg5::OnBnClickedButton37)
	ON_BN_CLICKED(IDC_BUTTON38, &CDlg5::OnBnClickedButton38)
	ON_BN_CLICKED(IDC_BUTTON39, &CDlg5::OnBnClickedButton39)
	ON_BN_CLICKED(IDC_BUTTON40, &CDlg5::OnBnClickedButton40)
	ON_BN_CLICKED(IDC_BUTTON41, &CDlg5::OnBnClickedButton41)
	ON_BN_CLICKED(IDC_BUTTON12, &CDlg5::OnBnClickedButton12)
END_MESSAGE_MAP()





BOOL CDlg5::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_V_checkLimitCredit.SetCheck(true);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CDlg5 message handlers

void CDlg5::OnButton1() 
{
	// TODO: Add extra validation here
	int ret,i;

	unsigned char tempbuff[2048];
	unsigned char tempbuf2[2048];
	CString neirong;//����һ���ַ����ı���
	CString temp,temp1;
	//
	PiccAutoRATS(1);
	PiccReset(10);//ms

	ret = PiccActivateA(0,0x52,&tempbuff[0],&tempbuff[2],&tempbuff[3],&tempbuff[4]) ;
	//
	if(ret==OK)
	{
		ret = PiccRequestATS(0,&tempbuf2[0],&tempbuf2[1]);//0 ms is RST and close
		if(ret==OK)
		{		
			ret = SetBuzzer(0x03,0x01);
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nATQ:";
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[0]);
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[1]);
			temp+=temp1;
			temp+="\r\n";
			//
			temp1.Format(" %02X",tempbuff[2]);
			temp+="SAK:";
			temp+=temp1;
			temp+="\r\n";
			//
			temp+="UID:";

			//temp.Format("\r\n-----------------------------------------------------\r\nSuccessed!\r\n\r\nUID Length:%s \r\nCard ID:",CPublic::DtoOX(tempbuff[3]));
			for(int i=0;i < tempbuff[3];i++)
			{
				temp1.Format(" %02X",tempbuff[4+i]);
				temp+=temp1;
			}
			//
			temp1 = "\r\nATS:";
			temp+=temp1;
			for(i=0;i < tempbuf2[0];i++)
			{
				temp1.Format(" %02X",tempbuf2[1+i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nRATS Fail!";
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
		temp1 = "\r\nError Code:";
		temp+=temp1;
		temp1.Format(" %02X",ret);
		temp+=temp1;
	}


	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnButton9() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");		
}

void CDlg5::OnButton2() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char buffer[2048];
	unsigned long aid = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT11))->GetWindowText(m_V_editAPP);
	strcpy((char *)buffer,m_V_editAPP);
	CPublic::OXStrtoD(strSize1,buffer);
	if (3 < strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must < 3Bytes!";
	}
	else
	{
		//
		aid = (((unsigned long)buffer[2])<<16)&0x00ff0000;
		aid|= (((unsigned long)buffer[1])<<8)&0x0000ff00;
		aid|= buffer[0];
		ret = DESSelectApplication(aid);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnButton3() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2;
	unsigned char buffer[2048];
	unsigned char tempbuff[2048];
	unsigned long aid = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT15))->GetWindowText(m_V_editDES16Key);
	strcpy((char *)buffer,m_V_editDES16Key);
	CPublic::OXStrtoD(strSize1,buffer);
	//
	(GetDlgItem(IDC_EDIT2))->GetWindowText(m_V_editKeyNo);
	strcpy((char *)tempbuff,m_V_editKeyNo);
	CPublic::OXStrtoD(strSize2,tempbuff);
	//
	if (16 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must be 16Bytes!";
	}
	else
	{
		ret = DESAuthenticate(tempbuff[0],buffer);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg5::OnButton10() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	int strSize2;
	int strSize3;
	int strSize4;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char tempbuff1[2048];
	unsigned char tempbuff2[2048];
	unsigned long aid = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT15))->GetWindowText(m_V_editDES16Key);
	strcpy((char *)buffer1,m_V_editDES16Key);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	(GetDlgItem(IDC_EDIT16))->GetWindowText(m_V_editDESNew16Key);
	strcpy((char *)buffer2,m_V_editDESNew16Key);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	(GetDlgItem(IDC_EDIT3))->GetWindowText(m_V_editNewKeySetting);
	strcpy((char *)tempbuff1,m_V_editNewKeySetting);
	CPublic::OXStrtoD(strSize3,tempbuff1);
	//
	(GetDlgItem(IDC_EDIT2))->GetWindowText(m_V_editKeyNo);
	strcpy((char *)tempbuff2,m_V_editKeyNo);
	CPublic::OXStrtoD(strSize4,tempbuff2);
	//
	if( (16 != strSize1)||(16 != strSize2)||(1 != strSize3)||(1 != strSize4) )
	{
		temp = "\r\n^----------------------------------------------------\r\nData length Error,and Key No. and Key Setting must In!";
	}
	else
	{
		ret = DESChangKey(tempbuff2[0],tempbuff1[0],buffer2,buffer1);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	
}

void CDlg5::OnButton4() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;

	unsigned char tempbuff[2048];
	unsigned char i;
	CString neirong,temp,temp1;
	//

	ret = DESGetApplicationIDs(&tempbuff[0],&tempbuff[1]);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nIDs:";
		temp+=temp1;
		temp1.Format(" %02X",tempbuff[0]);
		temp+=temp1;
		for(i=0;i<(tempbuff[0]*3);i+=3)
		{
			temp1 = "\r\nID:";
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[1+i]);
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[i+2]);
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[i+3]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	
}

void CDlg5::OnButton6() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp;
	//

	ret = DESFormatPicc();
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);		
}

void CDlg5::OnButton7() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned long aid = 0;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT4))->GetWindowText(m_V_editNewAppKeyNo);
	strcpy((char *)buffer3,m_V_editNewAppKeyNo);
	CPublic::OXStrtoD(strSize1,buffer3);
	//
	(GetDlgItem(IDC_EDIT12))->GetWindowText(m_V_editNewAPPKeySetting);
	strcpy((char *)buffer2,m_V_editNewAPPKeySetting);
	CPublic::OXStrtoD(strSize1,buffer2);
	//
	(GetDlgItem(IDC_EDIT11))->GetWindowText(m_V_editAPP);
	strcpy((char *)buffer1,m_V_editAPP);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	if (3 < strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nAppID length must = 3Bytes!";
	}
	else
	{
		aid = (((unsigned long)buffer1[2])<<16)&0x00ff0000;
		aid|= (((unsigned long)buffer1[1])<<8)&0x0000ff00;
		aid|= buffer1[0];
		//
		ret = DESCreateApplication(aid,buffer2[0],buffer3[0]);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}



void CDlg5::OnButton8() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;

	unsigned char tempbuff[2048];
	unsigned char i;
	CString neirong,temp,temp1;
	//

	ret = DESGetFileIDs(&tempbuff[0],&tempbuff[1]);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nIDs:";
		temp+=temp1;
		temp1.Format(" %02X",tempbuff[0]);
		temp+=temp1;
		for(i=0;i<tempbuff[0];i++)
		{
			temp1 = "\r\nID:";
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[1+i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	
}

void CDlg5::OnButton22() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3,strSize4;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned char buffer4[2048];
	unsigned short accesseri = 0;
	unsigned short filesi = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	(GetDlgItem(IDC_EDIT7))->GetWindowText(m_V_editNewComSet);
	strcpy((char *)buffer2,m_V_editNewComSet);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	(GetDlgItem(IDC_EDIT8))->GetWindowText(m_V_editNewAcessRight);
	strcpy((char *)buffer3,m_V_editNewAcessRight);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	(GetDlgItem(IDC_EDIT9))->GetWindowText(m_V_editNewFileSize);
	strcpy((char *)buffer4,m_V_editNewFileSize);
	CPublic::OXStrtoD(strSize4,buffer4);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nCom.Set. length must = 1Bytes!";
	}
	else if (2 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nAccessRight length must = 2Bytes!";
	}
	else if (2 != strSize4)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile Size must = 2Bytes!";
	}
	else
	{
		accesseri = (buffer3[1]*256);
		accesseri+= buffer3[0];
		//
		filesi = (buffer4[1]*256);
		filesi += buffer4[0];
		//
		ret = DESCreateStdDataFile(buffer1[0],buffer2[0],accesseri,filesi);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnButton23() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char buffer1[2048];
	CString neirong,temp,temp1;
	//
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 1Bytes!";
	}
	else
	{
		ret = DESDeleteDESFile(buffer1[0]);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	
}

void CDlg5::OnButton19() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3;
	unsigned char buffer[2048];
	unsigned char buffer1[2048];
	unsigned char buffer3[2048];
	unsigned long aid = 0;
	unsigned short len3;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT14))->GetWindowText(m_V_editFiledata);
	strcpy((char *)buffer,m_V_editFiledata);
	CPublic::OXStrtoD(strSize1,buffer);
	////
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize2,buffer1);
	//
	(GetDlgItem(IDC_EDIT24))->GetWindowText(m_V_editFileOffset);
	strcpy((char *)buffer3,m_V_editFileOffset);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 1Bytes!";
	}
	else if (280 < strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must < 280Bytes!";
	}
	else
	{
		//
		len3 = (((unsigned short)buffer3[1])<<8)&0xff00;
		len3|= buffer3[0];
		//
		ret = DESWriteData(buffer1[0],len3,strSize1,buffer);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	
}

void CDlg5::OnButton20() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3;
	unsigned char buffer[2048];
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned short len1,len2;
	unsigned long aid = 0;
	unsigned short relen = 0;
	unsigned short cd = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer3,m_V_editNewFile);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	(GetDlgItem(IDC_EDIT24))->GetWindowText(m_V_editFileOffset);
	strcpy((char *)buffer1,m_V_editFileOffset);
	CPublic::OXStrtoD(strSize1,buffer1);
	////
	(GetDlgItem(IDC_EDIT25))->GetWindowText(m_V_editFiledatalen);
	strcpy((char *)buffer2,m_V_editFiledatalen);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	if (2 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nOffset length must = 2Bytes!";
	}
	else if (2 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 2Bytes!";
	}
	else if (1 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else
	{
		//
		len1 = (((unsigned short)buffer1[1])<<8)&0xff00;
		len1|= buffer1[0];
		//
		len2 = (((unsigned short)buffer2[1])<<8)&0xff00;
		len2|= buffer2[0];
		//
		ret = DESReadData(buffer3[0],len1,len2,&buffer[0],&relen);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nData:";
			temp+=temp1;
			for(cd=0;cd<relen;cd++)
			{
				temp1.Format(" %02X",buffer[cd]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	
}

void CDlg5::OnBnClickedButton5()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;

	unsigned char tempbuff[2048];
	unsigned char i;
	CString neirong,temp,temp1;
	//

	ret = DESGetDESVersion(&tempbuff[0],&tempbuff[1]);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nVersion Information:";
		temp+=temp1;
		for(i=0;i<tempbuff[0];i++)
		{
			temp1.Format(" %02X",tempbuff[1+i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton13()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT2))->GetWindowText(m_V_editKeyNo);
	strcpy((char *)tempbuff,m_V_editKeyNo);
	CPublic::OXStrtoD(strSize1,tempbuff);

	ret = DESGetKeyVersion(tempbuff[0],&tempbuff[1]);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nKey Number:";
		temp+=temp1;
		temp1.Format(" %02X",tempbuff[0]);
		temp+=temp1;
		//
		temp1 = "\r\nKey Version:";
		temp+=temp1;
		temp1.Format(" %02X",tempbuff[1]);
		temp+=temp1;
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton11()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	//
	ret = DESGetKeySetting(&tempbuff[0],&tempbuff[1]);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nKey Settings:";
		temp+=temp1;
		temp1.Format(" %02X",tempbuff[0]);
		temp+=temp1;
		//
		temp1 = "\r\nMax No of Key:";
		temp+=temp1;
		temp1.Format(" %02X",tempbuff[1]);
		temp+=temp1;
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton14()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char buffer[2048];
	unsigned long aid = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT11))->GetWindowText(m_V_editAPP);
	strcpy((char *)buffer,m_V_editAPP);
	CPublic::OXStrtoD(strSize1,buffer);
	if (3 < strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must < 3Bytes!";
	}
	else
	{
		//
		aid = (((unsigned long)buffer[2])<<16)&0x00ff0000;
		aid|= (((unsigned long)buffer[1])<<8)&0x0000ff00;
		aid|= buffer[0];
		ret = DESDeleteApplication(aid);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton15()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize2;
	unsigned char buffer[2048];
	unsigned char buffer1[2048];
	unsigned char relen = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize2,buffer1);
	//
	if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 1Bytes!";
	}
	else
	{
		//
		ret = DESGetFileSettings(buffer1[0],&relen,&buffer[0]);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nFile Setting Length:";
			temp+=temp1;
			temp1.Format(" %02X",buffer[0]);
			temp+=temp1;
			temp1 = "\r\nFile Setting:";
			temp+=temp1;
			for(int i=0;i <(relen-1);i++)
			{
				temp1.Format(" %02X",buffer[1+i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton16()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned short accesseri = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	(GetDlgItem(IDC_EDIT7))->GetWindowText(m_V_editNewComSet);
	strcpy((char *)buffer2,m_V_editNewComSet);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	(GetDlgItem(IDC_EDIT8))->GetWindowText(m_V_editNewAcessRight);
	strcpy((char *)buffer3,m_V_editNewAcessRight);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nCom.Set. length must = 1Bytes!";
	}
	else if (2 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nAccessRight length must = 2Bytes!";
	}
	else
	{
		accesseri = buffer3[1];
		accesseri = ((accesseri<<8)&0xFF00);
		accesseri = (accesseri|buffer3[0]);
		//
		ret = DESChangeFileSettings(buffer1[0],buffer2[0],accesseri);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton17()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3,strSize4;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned char buffer4[2048];
	unsigned short accesseri = 0;
	unsigned short filesi = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	(GetDlgItem(IDC_EDIT7))->GetWindowText(m_V_editNewComSet);
	strcpy((char *)buffer2,m_V_editNewComSet);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	(GetDlgItem(IDC_EDIT8))->GetWindowText(m_V_editNewAcessRight);
	strcpy((char *)buffer3,m_V_editNewAcessRight);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	(GetDlgItem(IDC_EDIT9))->GetWindowText(m_V_editNewFileSize);
	strcpy((char *)buffer4,m_V_editNewFileSize);
	CPublic::OXStrtoD(strSize4,buffer4);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nCom.Set. length must = 1Bytes!";
	}
	else if (2 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nAccessRight length must = 2Bytes!";
	}
	else if (2 != strSize4)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile Size must = 2Bytes!";
	}
	else
	{
		accesseri = buffer3[1];
		accesseri = ((accesseri<<8)&0xFF00);
		accesseri = (accesseri|buffer3[0]);
		//
		filesi = buffer4[1];
		filesi = ((filesi<<8)&0xFF00);
		filesi = (filesi|buffer4[0]);
		//
		ret = DESCreateBackupDataFile(buffer1[0],buffer2[0],accesseri,filesi);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton18()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3,strSize4,strSize5,strSize6;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned char buffer4[2048];
	unsigned char buffer5[2048];
	unsigned char buffer6[2048];
	unsigned char limitCredit = 0;
	unsigned short accesseri = 0;
	unsigned long lowerLimit = 0;
	unsigned long upperLimit = 0;
	unsigned long filevalue  = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	(GetDlgItem(IDC_EDIT7))->GetWindowText(m_V_editNewComSet);
	strcpy((char *)buffer2,m_V_editNewComSet);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	(GetDlgItem(IDC_EDIT8))->GetWindowText(m_V_editNewAcessRight);
	strcpy((char *)buffer3,m_V_editNewAcessRight);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	(GetDlgItem(IDC_EDIT10))->GetWindowText(m_V_editLowerLimit);
	strcpy((char *)buffer4,m_V_editLowerLimit);
	CPublic::OXStrtoD(strSize4,buffer4);
	//
	(GetDlgItem(IDC_EDIT22))->GetWindowText(m_V_editUpperLimit);
	strcpy((char *)buffer5,m_V_editUpperLimit);
	CPublic::OXStrtoD(strSize5,buffer5);
	//
	(GetDlgItem(IDC_EDIT23))->GetWindowText(m_V_editFileValue);
	strcpy((char *)buffer6,m_V_editFileValue);
	CPublic::OXStrtoD(strSize6,buffer6);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nCom.Set. length must = 1Bytes!";
	}
	else if (2 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nAccessRight length must = 2Bytes!";
	}
	else if (4 != strSize4)
	{
		temp = "\r\n^----------------------------------------------------\r\nLowerLimit Size must = 4Bytes!";
	}
	else if (4 != strSize5)
	{
		temp = "\r\n^----------------------------------------------------\r\nUpperLimit Size must = 4Bytes!";
	}
	else if (4 != strSize6)
	{
		temp = "\r\n^----------------------------------------------------\r\nValue Size must = 4Bytes!";
	}
	else
	{
		accesseri = buffer3[1];
		accesseri = ((accesseri<<8)&0xFF00);
		accesseri = (accesseri|buffer3[0]);
		//
		lowerLimit = (((unsigned long)buffer4[3])<<24)&0xff000000;
		lowerLimit|= (((unsigned long)buffer4[2])<<16)&0x00ff0000;
		lowerLimit|= (((unsigned long)buffer4[1])<<8)&0x0000ff00;
		lowerLimit|= buffer4[0];
		//
		upperLimit = (((unsigned long)buffer5[3])<<24)&0xff000000;
		upperLimit|= (((unsigned long)buffer5[2])<<16)&0x00ff0000;
		upperLimit|= (((unsigned long)buffer5[1])<<8)&0x0000ff00;
		upperLimit|= buffer5[0];
		//
		filevalue = (((unsigned long)buffer6[3])<<24)&0xff000000;
		filevalue|= (((unsigned long)buffer6[2])<<16)&0x00ff0000;
		filevalue|= (((unsigned long)buffer6[1])<<8)&0x0000ff00;
		filevalue|= buffer6[0];
		//
		limitCredit = IsDlgButtonChecked(IDC_CHECK1);
		if(limitCredit!=0)
		{
			limitCredit = 1;
		}
		//
		ret = DESCreateValueFile(buffer1[0],buffer2[0],accesseri,lowerLimit,upperLimit,filevalue,limitCredit);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}



void CDlg5::OnBnClickedButton21()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize2;
	unsigned char buffer[2048];
	unsigned char buffer1[2048];
	long revalue = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize2,buffer1);
	//
	if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else
	{
		//
		ret = DESGetValue(buffer1[0],&revalue);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nValue Is:";
			temp+=temp1;
			//
			buffer[0] = (unsigned char)revalue;
			buffer[1] = (unsigned char)(revalue>>8);
			buffer[2] = (unsigned char)(revalue>>16);
			buffer[3] = (unsigned char)(revalue>>24);
			//
			for(int i=0;i <4;i++)
			{
				temp1.Format(" %02X",buffer[i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton30()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize2,strSize6;
	unsigned char buffer1[2048];
	unsigned char buffer6[2048];
	long filevalue = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize2,buffer1);
	//
	(GetDlgItem(IDC_EDIT23))->GetWindowText(m_V_editFileValue);
	strcpy((char *)buffer6,m_V_editFileValue);
	CPublic::OXStrtoD(strSize6,buffer6);
	//
	if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else
	{
		//
		filevalue = (((unsigned long)buffer6[3])<<24)&0xff000000;
		filevalue|= (((unsigned long)buffer6[2])<<16)&0x00ff0000;
		filevalue|= (((unsigned long)buffer6[1])<<8)&0x0000ff00;
		filevalue|= buffer6[0];
		//
		ret = DESOperateValue(buffer1[0],MF3_CREDIT,filevalue);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton31()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize2,strSize6;
	unsigned char buffer1[2048];
	unsigned char buffer6[2048];
	long filevalue = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize2,buffer1);
	//
	(GetDlgItem(IDC_EDIT23))->GetWindowText(m_V_editFileValue);
	strcpy((char *)buffer6,m_V_editFileValue);
	CPublic::OXStrtoD(strSize6,buffer6);
	//
	if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else
	{
		//
		filevalue = (((unsigned long)buffer6[3])<<24)&0xff000000;
		filevalue|= (((unsigned long)buffer6[2])<<16)&0x00ff0000;
		filevalue|= (((unsigned long)buffer6[1])<<8)&0x0000ff00;
		filevalue|= buffer6[0];
		//
		ret = DESOperateValue(buffer1[0],MF3_DEBIT,filevalue);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton32()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize2,strSize6;
	unsigned char buffer1[2048];
	unsigned char buffer6[2048];
	long filevalue = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize2,buffer1);
	//
	(GetDlgItem(IDC_EDIT23))->GetWindowText(m_V_editFileValue);
	strcpy((char *)buffer6,m_V_editFileValue);
	CPublic::OXStrtoD(strSize6,buffer6);
	//
	if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else
	{
		//
		filevalue = (((unsigned long)buffer6[3])<<24)&0xff000000;
		filevalue|= (((unsigned long)buffer6[2])<<16)&0x00ff0000;
		filevalue|= (((unsigned long)buffer6[1])<<8)&0x0000ff00;
		filevalue|= buffer6[0];
		//
		ret = DESOperateValue(buffer1[0],MF3_LIMITEDCREDIT,filevalue);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton35()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	//
	ret = DESTransaction(MF3_COMMITTRANS);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton36()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	//
	ret = DESTransaction(MF3_ABORTTRANS);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton37()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3,strSize4,strSize5;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned char buffer4[2048];
	unsigned char buffer5[2048];
	unsigned short accesseri = 0;
	unsigned short filesi = 0;
	unsigned short recorsnum = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	(GetDlgItem(IDC_EDIT7))->GetWindowText(m_V_editNewComSet);
	strcpy((char *)buffer2,m_V_editNewComSet);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	(GetDlgItem(IDC_EDIT8))->GetWindowText(m_V_editNewAcessRight);
	strcpy((char *)buffer3,m_V_editNewAcessRight);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	(GetDlgItem(IDC_EDIT9))->GetWindowText(m_V_editNewFileSize);
	strcpy((char *)buffer4,m_V_editNewFileSize);
	CPublic::OXStrtoD(strSize4,buffer4);
	//
	(GetDlgItem(IDC_EDIT26))->GetWindowText(m_V_editRecordsNum);
	strcpy((char *)buffer5,m_V_editRecordsNum);
	CPublic::OXStrtoD(strSize5,buffer5);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nCom.Set. length must = 1Bytes!";
	}
	else if (2 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nAccessRight length must = 2Bytes!";
	}
	else if (2 != strSize4)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile Size must = 2Bytes!";
	}
	else if (2 != strSize5)
	{
		temp = "\r\n^----------------------------------------------------\r\nRecords Number Size must = 2Bytes!";
	}
	else
	{
		accesseri = buffer3[1];
		accesseri = ((accesseri<<8)&0xFF00);
		accesseri = (accesseri|buffer3[0]);
		//
		filesi = buffer4[1];
		filesi = ((filesi<<8)&0xFF00);
		filesi = (filesi|buffer4[0]);
		//
		recorsnum = buffer5[1];
		recorsnum = ((recorsnum<<8)&0xFF00);
		recorsnum = (recorsnum|buffer5[0]);
		//
		ret = DESCreateLinearRecordFile(buffer1[0],buffer2[0],accesseri,filesi,recorsnum);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton38()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3,strSize4,strSize5;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned char buffer4[2048];
	unsigned char buffer5[2048];
	unsigned short accesseri = 0;
	unsigned short filesi = 0;
	unsigned short recorsnum = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	(GetDlgItem(IDC_EDIT7))->GetWindowText(m_V_editNewComSet);
	strcpy((char *)buffer2,m_V_editNewComSet);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	(GetDlgItem(IDC_EDIT8))->GetWindowText(m_V_editNewAcessRight);
	strcpy((char *)buffer3,m_V_editNewAcessRight);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	(GetDlgItem(IDC_EDIT9))->GetWindowText(m_V_editNewFileSize);
	strcpy((char *)buffer4,m_V_editNewFileSize);
	CPublic::OXStrtoD(strSize4,buffer4);
	//
	(GetDlgItem(IDC_EDIT26))->GetWindowText(m_V_editRecordsNum);
	strcpy((char *)buffer5,m_V_editRecordsNum);
	CPublic::OXStrtoD(strSize5,buffer5);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nCom.Set. length must = 1Bytes!";
	}
	else if (2 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nAccessRight length must = 2Bytes!";
	}
	else if (2 != strSize4)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile Size must = 2Bytes!";
	}
	else if (2 != strSize5)
	{
		temp = "\r\n^----------------------------------------------------\r\nRecords Number Size must = 2Bytes!";
	}
	else
	{
		accesseri = buffer3[1];
		accesseri = ((accesseri<<8)&0xFF00);
		accesseri = (accesseri|buffer3[0]);
		//
		filesi = buffer4[1];
		filesi = ((filesi<<8)&0xFF00);
		filesi = (filesi|buffer4[0]);
		//
		recorsnum = buffer5[1];
		recorsnum = ((recorsnum<<8)&0xFF00);
		recorsnum = (recorsnum|buffer5[0]);
		//
		ret = DESCreateCyclicRecordFile(buffer1[0],buffer2[0],accesseri,filesi,recorsnum);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton39()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3;
	unsigned char buffer[2048];
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned char buffer3[2048];
	unsigned short len1,len2;
	unsigned long aid = 0;
	unsigned short relen = 0;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer3,m_V_editNewFile);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	(GetDlgItem(IDC_EDIT24))->GetWindowText(m_V_editFileOffset);
	strcpy((char *)buffer1,m_V_editFileOffset);
	CPublic::OXStrtoD(strSize1,buffer1);
	////
	(GetDlgItem(IDC_EDIT25))->GetWindowText(m_V_editFiledatalen);
	strcpy((char *)buffer2,m_V_editFiledatalen);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	if (2 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nOffset length must = 2Bytes!";
	}
	else if (2 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 2Bytes!";
	}
	else if (1 != strSize3)
	{
		temp = "\r\n^----------------------------------------------------\r\nFile ID length must = 1Bytes!";
	}
	else
	{
		//
		len1 = (((unsigned short)buffer1[1])<<8)&0xff00;
		len1|= buffer1[0];
		//
		len2 = (((unsigned short)buffer2[1])<<8)&0xff00;
		len2|= buffer2[0];
		//
		ret = DESReadRecord(buffer3[0],len1,len2,&buffer[0],&relen);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nData:";
			temp+=temp1;
			for(int i=0;i < relen;i++)
			{
				temp1.Format(" %02X",buffer[i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton40()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1,strSize2,strSize3;
	unsigned char buffer[2048];
	unsigned char buffer1[2048];
	unsigned char buffer3[2048];
	unsigned long aid = 0;
	unsigned short len3;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT14))->GetWindowText(m_V_editFiledata);
	strcpy((char *)buffer,m_V_editFiledata);
	CPublic::OXStrtoD(strSize1,buffer);
	////
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize2,buffer1);
	//
	(GetDlgItem(IDC_EDIT24))->GetWindowText(m_V_editFileOffset);
	strcpy((char *)buffer3,m_V_editFileOffset);
	CPublic::OXStrtoD(strSize3,buffer3);
	//
	if (1 != strSize2)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 1Bytes!";
	}
	else if (280 < strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must < 280Bytes!";
	}
	else
	{
		//
		len3 = (((unsigned short)buffer3[1])<<8)&0xff00;
		len3|= buffer3[0];
		//
		ret = DESWriteRecord(buffer1[0],len3,strSize1,buffer);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton41()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char buffer1[2048];
	CString neirong,temp,temp1;
	//
	//
	(GetDlgItem(IDC_EDIT13))->GetWindowText(m_V_editNewFile);
	strcpy((char *)buffer1,m_V_editNewFile);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 1Bytes!";
	}
	else
	{
		ret = DESClearRecordFile(buffer1[0]);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg5::OnBnClickedButton12()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT3))->GetWindowText(m_V_editNewKeySetting);
	strcpy((char *)tempbuff,m_V_editNewKeySetting);
	CPublic::OXStrtoD(strSize1,tempbuff);
	//
	if (1 != strSize1)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must = 1Bytes!";
	}
	{
		ret = DESChangKeySetting(tempbuff[0]);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nKey Settings:";
			temp+=temp1;
			temp1.Format(" %02X",tempbuff[0]);
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}

	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}
