#include "afxwin.h"
#if !defined(AFX_DLG3_H__3EE1BC42_C055_48AC_B41B_CD28F1DABF2A__INCLUDED_)
#define AFX_DLG3_H__3EE1BC42_C055_48AC_B41B_CD28F1DABF2A__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000
// Dlg3.h : header file
//

/////////////////////////////////////////////////////////////////////////////
// CDlg3 dialog

class CDlg3 : public CDialog
{
// Construction
public:
	CDlg3(CWnd* pParent = NULL);   // standard constructor

// Dialog Data
	//{{AFX_DATA(CDlg3)
	enum { IDD = IDD_DIALOG3 };
		// NOTE: the ClassWizard will add data members here
	//}}AFX_DATA


// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CDlg3)
	protected:
	virtual void DoDataExchange(CDataExchange* pDX);    // DDX/DDV support
	//}}AFX_VIRTUAL

// Implementation
protected:

	// Generated message map functions
	//{{AFX_MSG(CDlg3)
		// NOTE: the ClassWizard will add member functions here
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
public:
	afx_msg void OnBnClickedButton1();
	virtual BOOL OnInitDialog();
	CComboBox m_C_cobSoltNO;
	afx_msg void OnBnClickedButton2();
	CString IDC_editAPDUCmd;
	afx_msg void OnBnClickedButton3();
	afx_msg void OnBnClickedButton4();
	afx_msg void OnBnClickedButton16();
	afx_msg void OnBnClickedButton18();
	CComboBox m_C_cobbaundrate;
};

//{{AFX_INSERT_LOCATION}}
// Microsoft Visual C++ will insert additional declarations immediately before the previous line.

#endif // !defined(AFX_DLG3_H__3EE1BC42_C055_48AC_B41B_CD28F1DABF2A__INCLUDED_)
