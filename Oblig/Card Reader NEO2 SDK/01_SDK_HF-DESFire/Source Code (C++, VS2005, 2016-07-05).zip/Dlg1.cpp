// Dlg1.cpp : implementation file
//
#include <windows.h>
#include "stdafx.h"
#include "COMM.h"
#include "Dlg1.h"
#include "Public.h"
#include "MYDLL.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

BOOL READ_CARDID = 0;
BOOL READ_CARDTICK= 0;

BOOL READ_QUEUE = 0;
BOOL READ_QUEUETICK= 0;

/////////////////////////////////////////////////////////////////////////////
// CDlg1 dialog

CDlg1::CDlg1(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg1::IDD, pParent)
	, m_V_editFlash_datawrite(_T("23 00 10 00 00 54 02 61 D4 C1 41 33 35 30 33 38"))
	, m_V_editFlash_Offset(_T("10 00 00 00"))
	, m_V_editFlash_Length(_T("08 00 00 00"))
{
	//{{AFX_DATA_INIT(CDlg1)
	//}}AFX_DATA_INIT
}


void CDlg1::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg1)
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COMBO1, m_C_cobCOM);
	DDX_Control(pDX, IDC_COMBO2, m_C_cobBaudrate);
	DDX_Control(pDX, IDC_COMBO3, m_C_cobNewBaudrate);
	DDX_Control(pDX, IDC_SLIDER1, m_SliderListTime);
	DDX_Text(pDX, IDC_EDIT21, m_V_editFlash_datawrite);
	DDX_Text(pDX, IDC_EDIT2, m_V_editFlash_Offset);
	DDX_Text(pDX, IDC_EDIT3, m_V_editFlash_Length);
}


BEGIN_MESSAGE_MAP(CDlg1, CDialog)
	//{{AFX_MSG_MAP(CDlg1)
	ON_BN_CLICKED(IDC_BUTTON5, OnButton5)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON6, OnBnClickedButton6)
	ON_BN_CLICKED(IDC_BUTTON4, OnBnClickedButton4)
	ON_WM_TIMER()
	ON_BN_CLICKED(IDC_BUTTON11, &CDlg1::OnBnClickedButton11)
	ON_NOTIFY(NM_CUSTOMDRAW, IDC_SLIDER1, &CDlg1::OnNMCustomdrawSlider1)
	ON_BN_CLICKED(IDC_BUTTON12, &CDlg1::OnBnClickedButton12)
	ON_BN_CLICKED(IDC_BUTTON13, &CDlg1::OnBnClickedButton13)
	ON_BN_CLICKED(IDC_BUTTON14, &CDlg1::OnBnClickedButton14)
	ON_BN_CLICKED(IDC_BUTTON7, &CDlg1::OnBnClickedButton7)
	ON_BN_CLICKED(IDC_BUTTON8, &CDlg1::OnBnClickedButton8)
	ON_BN_CLICKED(IDC_BUTTON9, &CDlg1::OnBnClickedButton9)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg1 message handlers


void CDlg1::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString str,strTmp;
	CString neirong,temp,temp1;
	long mBaudrate;
	int ret;

	GetDlgItemText(IDC_BUTTON1,strTmp);

	if(strTmp=="Open")
	{
		if(m_C_cobCOM.GetCurSel()==0)
		{
			ret = openhid(0x0483,0x5750,NULL);
		}
		else
		{
			GetDlgItemText(IDC_COMBO2,strTmp);
			mBaudrate = atol(strTmp);
			ret = open(m_C_cobCOM.GetCurSel(),mBaudrate);
		}
		if(ret==OK)
		{
			(GetDlgItem(IDC_BUTTON1))->SetWindowText("Close");
			(GetDlgItem(IDC_COMBO1))->EnableWindow(0);
			(GetDlgItem(IDC_COMBO2))->EnableWindow(0);
			timeout(5000);

			temp = "\r\n^----------------------------------------------------\r\nOpen Successed!";
			temp+=temp1;
			temp+=strTmp;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nOpen Fail!";
			temp+=temp1;
			temp+=strTmp;
		}

	}
	else
	{
		if(m_C_cobCOM.GetCurSel()==0)
		{
			closehid();
		}
		else
		{
			close();
		}
		(GetDlgItem(IDC_BUTTON1))->SetWindowText("Open");
		(GetDlgItem(IDC_COMBO1))->EnableWindow(1);
		(GetDlgItem(IDC_COMBO2))->EnableWindow(1);
		temp = "\r\n^----------------------------------------------------\r\nClose Successed!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

BOOL CDlg1::OnInitDialog()
{
	CDialog::OnInitDialog();
	CString str;

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_C_cobCOM.ResetContent();									//Ϊ������������ֵ
	//HID
	m_C_cobCOM.InsertString(0,"USB HID");
	//
	for (int i = 1;i < 26;i++)
	{
		str.Format("COM%d",i);
		m_C_cobCOM.InsertString(i,str);
	}
	m_C_cobCOM.SetCurSel(0);

	m_C_cobBaudrate.ResetContent();									//Ϊ������������ֵ
	
	m_C_cobBaudrate.InsertString(0,"115200");
	m_C_cobBaudrate.InsertString(1,"57600");
	m_C_cobBaudrate.InsertString(2,"38400");
	m_C_cobBaudrate.InsertString(3,"19200");
	m_C_cobBaudrate.InsertString(4,"9600");
	m_C_cobBaudrate.SetCurSel(0);

	m_C_cobNewBaudrate.ResetContent();									//Ϊ������������ֵ
	
	m_C_cobNewBaudrate.InsertString(0,"115200");
	m_C_cobNewBaudrate.InsertString(1,"57600");
	m_C_cobNewBaudrate.InsertString(2,"38400");
	m_C_cobNewBaudrate.InsertString(3,"19200");
	m_C_cobNewBaudrate.InsertString(4,"9600");
	m_C_cobNewBaudrate.SetCurSel(4);



	m_SliderListTime.SetRange(1,10,1);
	m_SliderListTime.SetPos(2);
	READ_CARDTICK = 200;
	SetTimer(1,100, NULL);

	//UpdateData(false);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlg1::OnBnClickedButton3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	CString strTmp;
	CString neirong,temp,temp1;
	long mBaudrate;
	int ret;
	unsigned char baund;


	GetDlgItemText(IDC_BUTTON1,strTmp);

	if(strTmp=="Close")
	{
		
		GetDlgItemText(IDC_COMBO3,strTmp);
		mBaudrate = atol(strTmp);
		switch(mBaudrate)
		{
		case 9600:
			baund = 4;
			break;
		case 19200:
			baund = 3;
			break;
		case 38400:
			baund = 2;
			break;
		case 57600:
			baund = 1;
			break;
		case 115200:
			baund = 0;
			break;
		default:
			break;
		}
		ret = SetUARTBaudRate(baund);	
		if(ret==OK)
		{
			ret = baud(mBaudrate);
			ret = m_C_cobNewBaudrate.GetCurSel();
			m_C_cobBaudrate.SetCurSel(ret);
			temp = "\r\n^----------------------------------------------------\r\nChange Successed!";
			temp1 = "\r\nBaundrate:";
			temp+=temp1;
			temp+=strTmp;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nChange Fail!";
		}

	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nChange Fail,Comm Not Open";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg1::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	ret = SetBuzzer(0x03,0x03);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg1::OnBnClickedButton6()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	ret = SetLed(0x10,0x03);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
		temp1.Format(" %02X",ret);
		temp+=temp1;
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg1::OnBnClickedButton4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
}

void CDlg1::OnButton5() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	ret = PiccADRcv(0x00,0x0A);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}


void CDlg1::OnTimer(UINT_PTR nIDEvent)
{
	//UpdateData(TRUE); //ʹ��֮�������
	int TLret = 1;
	unsigned char tempbuff[2048];
	unsigned char tempbuff1[128];
	unsigned short replen;
	unsigned char snlength = 0;
	unsigned char snmuch = 0;
	//

	//
	CString neirong,temp,temp1;
	//
	unsigned char ISO14443A,ISO15693;
	//
	ISO14443A = IsDlgButtonChecked(IDC_CHECK1);
	ISO15693  = IsDlgButtonChecked(IDC_CHECK2);
	//
	if(READ_CARDID!=0)
	{
		if(ISO14443A)
		{
			TLret = PiccActivateA(0x0A,0x52,&tempbuff[0],&tempbuff[2],&tempbuff[3],&tempbuff[4]) ;
			if(TLret==OK)
			{
				//SetBuzzer(0x03,0x01);
				temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
				temp1 = "\r\nATQ:";
				temp+=temp1;
				temp1.Format(" %02X",tempbuff[0]);
				temp+=temp1;
				temp1.Format(" %02X",tempbuff[1]);
				temp+=temp1;
				temp+="\r\n";
				//
				temp1.Format(" %02X",tempbuff[2]);
				temp+="SAK:";
				temp+=temp1;
				temp+="\r\n";
				//
				temp+="UID:";
				for(int i=0;i < tempbuff[3];i++)
				{
					temp1.Format(" %02X",tempbuff[4+i]);
					temp+=temp1;
				}		
			}
			else if(TLret==READTIMEOUT)
			{
				temp = "\r\n^----------------------------------------------------\r\nTimeOut Stop!";
			}
			else
			{
				temp = "\r\n^----------------------------------------------------\r\nISO14443A NO Card!";
				temp1 = "\r\nError Code:";
				temp+=temp1;
				temp1.Format(" %02X",TLret);
				temp+=temp1;
			}
			//
			GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
			SetDlgItemText(IDC_EDIT1,"\r\n");
			SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
		}
		

		//
		if(ISO15693)
		{
			if(IsDlgButtonChecked(IDC_CHECK5))
			{
				TLret = ISO15693_Inventory(0x06,0x00,0x00,tempbuff1,&replen,&tempbuff[0] );
			}
			else
			{
				TLret = ISO15693_Inventory(0x26,0x00,0x00,tempbuff1,&replen,&tempbuff[0] );
			}
			if(TLret==OK)
			{
				if( (replen%8)==0 )
				{
					snlength = 8;
					snmuch = (replen/8);
				}
				else
				{
					snlength = 0;
				}

				if( (snlength==8)&&(snmuch>1) )
				{
					//
					temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
					temp1 = "\r\nCard ID:\r\n";
					temp+=temp1;
					for(int j=0;j<snmuch;j++)
					{
						for(int i=0;i <8;i++)
						{
							temp1.Format(" %02X",tempbuff[(8*j)+i]);
							temp+=temp1;
						}
						temp+="\r\n";
					}			
					//
				}
				else if( (snlength==8)&&(snmuch==1) )
				{
					//
					temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
					temp1 = "\r\nCard ID:\r\n";
					temp+=temp1;
					for(int i=0;i <8;i++)
					{
						temp1.Format(" %02X",tempbuff[i]);
						temp+=temp1;
					}
					//
				}
				else
				{
					temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
					temp1 = "\r\nCard ID:\r\n";
					temp+=temp1;
					for(int i=0;i <replen;i++)
					{
						temp1.Format(" %02X",tempbuff[i]);
						temp+=temp1;
					}
				}
			}
			else if(TLret==READTIMEOUT)
			{
				temp = "\r\n^----------------------------------------------------\r\nTimeOut Stop!";
			}
			else
			{
				temp = "\r\n^----------------------------------------------------\r\nISO15693 NO Card!";
				temp1 = "\r\nError Code:";
				temp+=temp1;
				temp1.Format(" %02X",TLret);
				temp+=temp1;
			}
			//
			SetHalt();
			//
			GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
			SetDlgItemText(IDC_EDIT1,"\r\n");
			SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
		}
		
	}
	//UpdateData(FALSE);
	if(READ_QUEUE!=0)
	{
		TLret = QueueUartData(&snlength,&tempbuff[0]);
		if(TLret==OK)
		{
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nUart Data:\r\n";
			temp+=temp1;
			for(int j=0;j<snlength;j++)
			{
				temp1.Format(" %02X",tempbuff[j]);
				temp+=temp1;
			}	
			//
			GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
			SetDlgItemText(IDC_EDIT1,"\r\n");
			SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
			//
		}
		else
		{
			
		}	
	}

	CDialog::OnTimer(nIDEvent);
}

void CDlg1::OnBnClickedButton11()
{
	CString neirong,temp,temp1,strTmp;
	unsigned char ISO14443A,ISO15693;
	//
	ISO14443A = IsDlgButtonChecked(IDC_CHECK1);
	ISO15693  = IsDlgButtonChecked(IDC_CHECK2);
	//
	if(ISO14443A||ISO15693)
	{
		//
		GetDlgItemText(IDC_BUTTON11,strTmp);
		if(strTmp=="AutoListCard")
		{
			(GetDlgItem(IDC_BUTTON11))->SetWindowText("Stop");
			READ_CARDID = 1;
			timeout(500);
			temp = "\r\n^----------------------------------------------------\r\nAutoList Start!";
			//
			GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
			SetDlgItemText(IDC_EDIT1,"\r\n");
			SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
		}
		else
		{
			(GetDlgItem(IDC_BUTTON11))->SetWindowText("AutoListCard");
			READ_CARDID = 0;
			timeout(2000);
			temp = "\r\n^----------------------------------------------------\r\nStop OK!";
			//
			GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
			SetDlgItemText(IDC_EDIT1,"\r\n");
			SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
		}
	}
	else
	{
		(GetDlgItem(IDC_BUTTON11))->SetWindowText("AutoListCard");
		READ_CARDID = 0;
		timeout(2000);
		temp = "\r\n^----------------------------------------------------\r\nPlease Select Card Type!";
		//
		GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
		SetDlgItemText(IDC_EDIT1,"\r\n");
		SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	}
}

void CDlg1::OnNMCustomdrawSlider1(NMHDR *pNMHDR, LRESULT *pResult)
{
	LPNMCUSTOMDRAW pNMCD = reinterpret_cast<LPNMCUSTOMDRAW>(pNMHDR);
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int Label; 
	Label = m_SliderListTime.GetPos();
	READ_CARDTICK = Label*100;
	SetTimer(1,READ_CARDTICK, NULL);

	*pResult = 0;
}

void CDlg1::OnBnClickedButton12()
{
	unsigned char flashdata[1024];
	int strSize1,strSize2;
	unsigned char buffer1[2048];
	unsigned char buffer2[2048];
	unsigned int len1;
	unsigned short len2;
	int ret;
	CString neirong,temp,temp1;
	//
	
	//
	(GetDlgItem(IDC_EDIT2))->GetWindowText(m_V_editFlash_Offset);
	strcpy((char *)buffer1,m_V_editFlash_Offset);
	CPublic::OXStrtoD(strSize1,buffer1);
	////
	(GetDlgItem(IDC_EDIT3))->GetWindowText(m_V_editFlash_Length);
	strcpy((char *)buffer2,m_V_editFlash_Length);
	CPublic::OXStrtoD(strSize2,buffer2);
	//
	//length
	len2 = (((unsigned short)buffer2[1])<<8)&0xff00;
	len2|= buffer2[0];
	//offset
	len1 = (((unsigned short)buffer1[1])<<8)&0x0000ff00;
	len1|= buffer1[0];
	//
	//
	ret = PCD_Read_Flash(len1,len2,flashdata); 
	if(ret==OK)
	{

		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nFlash Data:";
		temp+=temp1;
		for(int i=0;i < len2;i++)
		{
			if(i==0)
			{
				temp1.Format("%02X",flashdata[i]);
			}
			else
			{
				temp1.Format(" %02X",flashdata[i]);
			}
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}

	//
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg1::OnBnClickedButton13()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048];
	unsigned char buffer1[2048];
	int ret;
	int strSize,strSize1;
	unsigned int len1;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT21))->GetWindowText(m_V_editFlash_datawrite);
	strcpy((char *)pBuf,m_V_editFlash_datawrite);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	(GetDlgItem(IDC_EDIT2))->GetWindowText(m_V_editFlash_Offset);
	strcpy((char *)buffer1,m_V_editFlash_Offset);
	CPublic::OXStrtoD(strSize1,buffer1);
	//
	if (256 < strSize)
	{
		temp = "\r\n^----------------------------------------------------\r\nData length must be < 256Bytes!";
	}
	else
	{
		//offset
		len1 = (((unsigned short)buffer1[1])<<8)&0x0000ff00;
		len1|= buffer1[0];
		//
		ret = PCD_Write_Flash(len1,strSize,pBuf); 
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg1::OnBnClickedButton14()
{
	CString neirong,temp,temp1,strTmp;
	//
	GetDlgItemText(IDC_BUTTON14,strTmp);
	if(strTmp=="QueueUart")
	{
		(GetDlgItem(IDC_BUTTON14))->SetWindowText("Stop");
		READ_CARDID = 0;
		READ_QUEUE = 1;
		READ_QUEUETICK = 10;
		SetTimer(1,READ_QUEUETICK, NULL);
		timeout(20);
		temp = "\r\n^----------------------------------------------------\r\nQueueUart Start!";
		//
		GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
		SetDlgItemText(IDC_EDIT1,"\r\n");
		SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	}
	else
	{
		(GetDlgItem(IDC_BUTTON14))->SetWindowText("QueueUart");
		READ_CARDID = 0;
		READ_QUEUE = 0;
		timeout(20);
		temp = "\r\n^----------------------------------------------------\r\nStop OK!";
		//
		GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
		SetDlgItemText(IDC_EDIT1,"\r\n");
		SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
	}
}

void CDlg1::OnBnClickedButton7()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	int ret;
	CString neirong,temp,temp1,carddata;
	//
	ret = GetReaderUID(&addr, pBuf);
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nReader ID:";
		temp+=temp1;
		for(int i=0;i < addr;i++)
		{
			temp1.Format(" %02X",pBuf[i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg1::OnBnClickedButton8()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char ant;
	int ret;
	CString neirong,temp,temp1;
	//
	ret = GetANT(&ant);
	if(ret==OK)
	{
		temp = "\r\n^-------------------------------------\r\nSuccessed!";
		temp1 = "\r\nANT:";
		temp+=temp1;
		temp1.Format(" %02X",ant);
		temp+=temp1;
	}
	else
	{
		temp = "\r\n^-------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg1::OnBnClickedButton9()
{
	CString neirong,temp,temp1,strTmp;
	unsigned char ANT1,ANT2,ANT3;
	//
	ANT1 = IsDlgButtonChecked(IDC_CHECK3);
	ANT2 = IsDlgButtonChecked(IDC_CHECK4);
	ANT3 = 0x00;
	if(ANT1)
	{
		ANT3 = ANT3|0x01;
	}
	if(ANT2)
	{
		ANT3 = ANT3|0x02;
	}
	//
	int ret = SetANT(ANT3);
	if(ret==OK)
	{
		temp = "\r\n^-------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^-------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}
