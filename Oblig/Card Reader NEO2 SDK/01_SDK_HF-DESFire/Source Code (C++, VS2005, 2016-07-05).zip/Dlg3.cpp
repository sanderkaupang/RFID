// Dlg3.cpp : implementation file
//
#include <windows.h>
#include "stdafx.h"
#include "COMM.h"
#include "Dlg3.h"
#include "Public.h"
#include "MYDLL.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/////////////////////////////////////////////////////////////////////////////
// CDlg3 dialog


CDlg3::CDlg3(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg3::IDD, pParent)
	, IDC_editAPDUCmd(_T("0084000008"))
{
	//{{AFX_DATA_INIT(CDlg3)
		// NOTE: the ClassWizard will add member initialization here
	//}}AFX_DATA_INIT
}


void CDlg3::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg3)
	// NOTE: the ClassWizard will add DDX and DDV calls here
	//}}AFX_DATA_MAP
	DDX_Control(pDX, IDC_COMBO1, m_C_cobSoltNO);
	DDX_Text(pDX, IDC_EDIT2, IDC_editAPDUCmd);
	DDV_MaxChars(pDX, IDC_editAPDUCmd, 1024);
	DDX_Control(pDX, IDC_COMBO2, m_C_cobbaundrate);
}


BEGIN_MESSAGE_MAP(CDlg3, CDialog)
	//{{AFX_MSG_MAP(CDlg3)
		// NOTE: the ClassWizard will add message map macros here
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON1, OnBnClickedButton1)
	ON_BN_CLICKED(IDC_BUTTON2, OnBnClickedButton2)
	ON_BN_CLICKED(IDC_BUTTON3, OnBnClickedButton3)
	ON_BN_CLICKED(IDC_BUTTON4, OnBnClickedButton4)
	ON_BN_CLICKED(IDC_BUTTON16, OnBnClickedButton16)
	ON_BN_CLICKED(IDC_BUTTON18, OnBnClickedButton18)
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CDlg3 message handlers

void CDlg3::OnBnClickedButton1()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char soltNo,slotstatus=0;
	CString neirong,temp,temp1;
	//
	soltNo = m_C_cobSoltNO.GetCurSel();
	int ret = IccCheck_Pres (soltNo, &slotstatus );
	if(ret==OK)
	{
		if(slotstatus==1)
		{
			temp = "\r\n^----------------------------------------------------\r\nCard in Slot!";
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nNo Card!";
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

BOOL CDlg3::OnInitDialog()
{
	CDialog::OnInitDialog();

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_C_cobSoltNO.ResetContent();
	m_C_cobSoltNO.InsertString(0,"ICC Slot");
	m_C_cobSoltNO.InsertString(1,"SAM Slot1");
	m_C_cobSoltNO.InsertString(2,"SAM Slot2");
	m_C_cobSoltNO.InsertString(3,"SAM Slot3");
	m_C_cobSoltNO.InsertString(4,"SAM Slot4");
	m_C_cobSoltNO.SetCurSel(0);

	// TODO:  �ڴ����Ӷ���ĳ�ʼ��
	m_C_cobbaundrate.ResetContent();									//Ϊ������������ֵ
	m_C_cobbaundrate.InsertString(0,"115200");
	m_C_cobbaundrate.InsertString(1,"57600");
	m_C_cobbaundrate.InsertString(2,"38400");
	m_C_cobbaundrate.InsertString(3,"19200");
	m_C_cobbaundrate.InsertString(4,"9600");
	m_C_cobbaundrate.SetCurSel(4);

	return TRUE;  // return TRUE unless you set the focus to a control
	// �쳣: OCX ����ҳӦ���� FALSE
}

void CDlg3::OnBnClickedButton2()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char soltNo;
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	//
	soltNo = m_C_cobSoltNO.GetCurSel();
	int ret = IccPowerUp (soltNo, &tempbuff[0],&tempbuff[1] );
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nATR:";
		temp+=temp1;
		for(int i=0;i < tempbuff[0];i++)
		{
			temp1.Format(" %02X",tempbuff[1+i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg3::OnBnClickedButton3()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	int strSize1;
	unsigned int strSize2;
	unsigned char buffer[2048];
	unsigned char tempbuff[2048];
	CString neirong,temp,temp1;
	//
	unsigned char soltNo = m_C_cobSoltNO.GetCurSel();
	(GetDlgItem(IDC_EDIT2))->GetWindowText(IDC_editAPDUCmd);
	strcpy((char *)buffer,IDC_editAPDUCmd);
	CPublic::OXStrtoD(strSize1,buffer);
	//
	ret = IccAPDU(soltNo,strSize1,&buffer[0],&strSize2,&tempbuff[0]);//0 ms is RST and close
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nRec:";
		temp+=temp1;
		for(unsigned int i=0;i < strSize2;i++)
		{
			temp1.Format(" %02X",tempbuff[i]);
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg3::OnBnClickedButton4()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	int ret;
	CString neirong,temp,temp1;
	unsigned char soltNo = m_C_cobSoltNO.GetCurSel();
	ret = IccPowerDn(soltNo);//0 ms is RST and close
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg3::OnBnClickedButton16()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
}

void CDlg3::OnBnClickedButton18()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char soltNo,slotstatus=0;
	CString neirong,temp,temp1;
	//
	slotstatus = m_C_cobbaundrate.GetCurSel();
	soltNo = m_C_cobSoltNO.GetCurSel();
	int ret = IccSetInitBaudrate (soltNo, slotstatus );
	if(ret==OK)
	{
		temp = "\r\n^----------------------------------------------------\r\nSet OK!";
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}
