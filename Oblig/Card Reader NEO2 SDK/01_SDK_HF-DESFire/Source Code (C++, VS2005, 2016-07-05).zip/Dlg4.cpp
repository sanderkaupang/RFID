// Dlg4.cpp : implementation file
//
#include <windows.h>
#include "stdafx.h"
#include "COMM.h"
#include "Dlg4.h"
#include "Public.h"
#include "MYDLL.h"


#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif


volatile unsigned char UID15693[8]={0,0,0,0,0,0,0,0};
/////////////////////////////////////////////////////////////////////////////
// CDlg4 dialog


CDlg4::CDlg4(CWnd* pParent /*=NULL*/)
	: CDialog(CDlg4::IDD, pParent)
	, m_V_edit15693uid(_T(""))
{
	//{{AFX_DATA_INIT(CDlg4)
	m_V_editflag = _T("22");
	m_V_edit4data = _T("11223344");
	m_V_editAFI = _T("07");
	m_V_editDSFID = _T("08");
	//}}AFX_DATA_INIT
}


void CDlg4::DoDataExchange(CDataExchange* pDX)
{
	CDialog::DoDataExchange(pDX);
	//{{AFX_DATA_MAP(CDlg4)
	DDX_Control(pDX, IDC_COMBO1, m_operBlock15693);
	DDX_Text(pDX, IDC_EDIT5, m_V_editflag);
	DDV_MaxChars(pDX, m_V_editflag, 2);
	DDX_Text(pDX, IDC_EDIT2, m_V_edit4data);
	DDV_MaxChars(pDX, m_V_edit4data, 8);
	DDX_Text(pDX, IDC_EDIT3, m_V_editAFI);
	DDV_MaxChars(pDX, m_V_editAFI, 2);
	DDX_Text(pDX, IDC_EDIT4, m_V_editDSFID);
	DDV_MaxChars(pDX, m_V_editDSFID, 2);
	//}}AFX_DATA_MAP
	DDX_Text(pDX, IDC_EDIT6, m_V_edit15693uid);
	DDX_Control(pDX, IDC_CHECK1, m_V_checkTimeSlot);
}


BEGIN_MESSAGE_MAP(CDlg4, CDialog)
	//{{AFX_MSG_MAP(CDlg4)
	ON_BN_CLICKED(IDC_BUTTON1, OnInventory)
	ON_BN_CLICKED(IDC_BUTTON9, OnClear)
	ON_BN_CLICKED(IDC_BUTTON2, OnReadBlock15693)
	ON_BN_CLICKED(IDC_BUTTON3, OnWriteblock15693)
	ON_BN_CLICKED(IDC_BUTTON10, OnLockBlock)
	ON_BN_CLICKED(IDC_BUTTON4, OnWriteAFI)
	ON_BN_CLICKED(IDC_BUTTON5, OnLockAFI)
	ON_BN_CLICKED(IDC_BUTTON6, OnWriteDSFID)
	ON_BN_CLICKED(IDC_BUTTON7, OnLockDSFID)
	ON_BN_CLICKED(IDC_BUTTON8, OnGetSysInfor)
	//}}AFX_MSG_MAP
	ON_BN_CLICKED(IDC_BUTTON19, &CDlg4::OnBnClickedButton19)
	ON_BN_CLICKED(IDC_BUTTON20, &CDlg4::OnBnClickedButton20)
END_MESSAGE_MAP()


BOOL CDlg4::OnInitDialog() 
{
	CDialog::OnInitDialog();
	unsigned short i;
	CString strTmp;
	//
	m_operBlock15693.ResetContent();
	for (i = 0;i < 256;i++)
	{
		strTmp.Format("%02X",i);
		m_operBlock15693.InsertString(i,strTmp);
	}
	m_operBlock15693.SetCurSel(5);
	m_V_checkTimeSlot.SetCheck(true);
	
	return TRUE;  // return TRUE unless you set the focus to a control
	              // EXCEPTION: OCX Property Pages should return FALSE
}

/////////////////////////////////////////////////////////////////////////////
// CDlg4 message handlers

void CDlg4::OnInventory() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char tempbuff1[128];
	unsigned char tempbuff[2048];
	unsigned short replen;
	unsigned char snlength = 0;
	unsigned char snmuch = 0;
	unsigned char timeslot = 0;
	CString neirong,temp,temp1,carid;
	//
	timeslot = IsDlgButtonChecked(IDC_CHECK1);
	if(timeslot)
	{
		timeslot = 0x06;	//List more than one card most is 16
	}
	else
	{
		timeslot = 0x26;	//List one card only
	}
	//
	int ret = ISO15693_Inventory(timeslot,0x00,0x00,tempbuff1,&replen,&tempbuff[0] );
	if(ret==OK)
	{
		if( (replen%8)==0 )
		{
			snlength = 8;
			snmuch = (replen/8);
		}
		else
		{
			snlength = 0;
		}

		if( (snlength==8)&&(snmuch>1) )
		{
			carid = "";
			(GetDlgItem(IDC_EDIT6))->SetWindowText(carid);
			(GetDlgItem(IDC_EDIT5))->SetWindowText("22");
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nCard ID:\r\n";
			temp+=temp1;
			for(int j=0;j<snmuch;j++)
			{
				carid = "";
				for(int i=0;i <8;i++)
				{
					temp1.Format(" %02X",tempbuff[(8*j)+i]);
					UID15693[i] = tempbuff[i];
					temp+=temp1;
					carid+=temp1;
				}
				temp+="\r\n";
			}			
			//
			(GetDlgItem(IDC_EDIT6))->SetWindowText(carid);
			//
		}
		else if( (snlength==8)&&(snmuch==1) )
		{
			(GetDlgItem(IDC_EDIT5))->SetWindowText("22");
			carid = "";
			//
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nCard ID:\r\n";
			temp+=temp1;
			for(int i=0;i <8;i++)
			{
				temp1.Format(" %02X",tempbuff[i]);
				UID15693[i] = tempbuff[i];
				temp+=temp1;
				carid+=temp1;
			}
			//
			(GetDlgItem(IDC_EDIT6))->SetWindowText(carid);
			//
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nCard ID:\r\n";
			temp+=temp1;
			for(int i=0;i <replen;i++)
			{
				temp1.Format(" %02X",tempbuff[i]);
				temp+=temp1;
			}
			//
			carid = "";
			(GetDlgItem(IDC_EDIT6))->SetWindowText(carid);
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
		carid = "";
		(GetDlgItem(IDC_EDIT6))->SetWindowText(carid);
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg4::OnClear() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");	
}

void CDlg4::OnReadBlock15693() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	unsigned char pBuf1[2048];
	unsigned short relen;
	int ret,strSize,strSize1;
	CString neirong,temp,temp1;
	//
	addr = m_operBlock15693.GetCurSel();
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	(GetDlgItem(IDC_EDIT6))->GetWindowText(m_V_edit15693uid);
	strcpy((char *)pBuf1,m_V_edit15693uid);
	CPublic::OXStrtoD(strSize1,pBuf1);
	//
	if((pBuf[0]==0x22)&&(strSize1<8))
	{
		temp = "\r\n^----------------------------------------------------\r\nFlag22 must With Card ID!";
	}
	else
	{
		//
		ret = ISO15693_Read_Block(pBuf[0],addr,0x01,pBuf1,&relen,&pBuf[10]);
		if((ret==OK)&&(relen>4))
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nRead Out Data:";
			temp+=temp1;
			for(int i=0;i<4;i++)
			{
				temp1.Format(" %02X",pBuf[12+i]);
				temp+=temp1;
			}
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg4::OnWriteblock15693() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048],pBuf1[2048],pBuf2[2048];
	unsigned short relen;
	int ret,strSize,strSize1,strSize2;
	CString neirong,temp,temp1;
	//
	addr = m_operBlock15693.GetCurSel();
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	(GetDlgItem(IDC_EDIT2))->GetWindowText(m_V_edit4data);
	strcpy((char *)pBuf1,m_V_edit4data);
	CPublic::OXStrtoD(strSize1,pBuf1);
	//
	(GetDlgItem(IDC_EDIT6))->GetWindowText(m_V_edit15693uid);
	strcpy((char *)pBuf2,m_V_edit15693uid);
	CPublic::OXStrtoD(strSize2,pBuf2);
	//
	if((pBuf[0]==0x22)&&(strSize2<8))
	{
		temp = "\r\n^----------------------------------------------------\r\nFlag22 must With Card ID!";
	}
	else
	{
		if(strSize1!=4)
		{
			temp = "\r\n^----------------------------------------------------\r\nLength must be 4 bytes for 1 block!";
		}
		else
		{
			//
			ret = ISO15693_Write_Block(pBuf[0],addr,0x01,pBuf2,pBuf1,&relen,&pBuf[100]);
			if((ret==OK)&&(pBuf[100]==0))
			{
				if(pBuf[101]==0x00)
				{
					temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
					temp1 = "\r\nWrite OK";
					temp+=temp1;
				}
				else
				{
					temp = "\r\n^----------------------------------------------------\r\nIn doubt!";
					temp1 = "\r\nBlock may have been locked ";
					temp+=temp1;
				}
			}
			else
			{
				temp = "\r\n^----------------------------------------------------\r\nFail!";
			}
		}
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);
}

void CDlg4::OnLockBlock() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char addr,pBuf[2048];
	unsigned short relen;
	int ret,strSize;
	CString neirong,temp,temp1;
	//
	addr = m_operBlock15693.GetCurSel();
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	memcpy(&pBuf[2],(unsigned char *)UID15693,8);
	//
	ret = ISO15693_Lock_Block(pBuf[0],addr,&pBuf[2],&relen,&pBuf[100]);
	if((ret==OK)&&(pBuf[100]==0x00))
	{
		if(pBuf[101]==0x00)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nLock OK";
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nIn doubt!";
			temp1 = "\r\nBlock may have been locked ";
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);		
}

void CDlg4::OnWriteAFI() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048],pBuf1[2048];
	unsigned short relen;
	int ret,strSize;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	(GetDlgItem(IDC_EDIT3))->GetWindowText(m_V_editAFI);
	strcpy((char *)pBuf1,m_V_editAFI);
	CPublic::OXStrtoD(strSize,pBuf1);
	//
	memcpy(&pBuf[2],(unsigned char *)UID15693,8);
	//
	ret = ISO15693_Write_AFI(pBuf[0],pBuf1[0],&pBuf[2],&relen,&pBuf[100]);
	if((ret==OK)&&(pBuf[100]==0))
	{
		if(pBuf[101]==0)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nWrite AFI OK";
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nIn doubt!";
			temp1 = "\r\nAFI may have been locked ";
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg4::OnLockAFI() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048];
	unsigned short relen;
	int ret,strSize;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	memcpy(&pBuf[2],(unsigned char *)UID15693,8);
	//
	ret = ISO15693_Lock_AFI(pBuf[0],&pBuf[2],&relen,&pBuf[100]);
	if((ret==OK)&&(pBuf[100]==0))
	{
		if(pBuf[101]==0)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nLock AFI OK";
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nIn doubt!";
			temp1 = "\r\nAFI may have been locked ";
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);		
}

void CDlg4::OnWriteDSFID() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048],pBuf1[2048];
	unsigned short relen;
	int ret,strSize;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	(GetDlgItem(IDC_EDIT4))->GetWindowText(m_V_editDSFID);
	strcpy((char *)pBuf1,m_V_editDSFID);
	CPublic::OXStrtoD(strSize,pBuf1);
	//
	memcpy(&pBuf[2],(unsigned char *)UID15693,8);
	//
	ret = ISO15693_Write_DSFID(pBuf[0],pBuf1[0],&pBuf[2],&relen,&pBuf[100]);
	if((ret==OK)&&(pBuf[100]==0))
	{
		if(pBuf[101]==0)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nWrite DSFID OK";
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nIn doubt!";
			temp1 = "\r\nDSFID may have been locked ";
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);		
}

void CDlg4::OnLockDSFID() 
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048];
	unsigned short relen;
	int ret,strSize;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	memcpy(&pBuf[2],(unsigned char *)UID15693,8);
	//
	ret = ISO15693_Lock_DSFID(pBuf[0],&pBuf[2],&relen,&pBuf[100]);
	if((ret==OK)&&(pBuf[100]==0))
	{
		if(pBuf[101]==0)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nLock DSFID OK";
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nIn doubt!";
			temp1 = "\r\nDSFID may have been locked ";
			temp+=temp1;
		}
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);		
}

void CDlg4::OnGetSysInfor() 
{
	//Length: 0021, Data: 50 00 10 AC 00 00 0F 47 5B 0A 3A 00 01 04 E0 00 00 1B 03 01 33 
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048];
	unsigned short relen;
	int ret,strSize;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	memcpy(&pBuf[2],(unsigned char *)UID15693,8);
	//
	ret = ISO15693_Get_SysInfor(pBuf[0],&pBuf[2],&relen,&pBuf[7]);
	if((ret==OK)&&(relen>12))
	{
		temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
		temp1 = "\r\nSysterm Information:";
		temp+=temp1;
		//
		temp+="\r\nUID:";
		for(int i=0;i<8;i++)
		{
			temp1.Format(" %02X",pBuf[10+i]);
			temp+=temp1;
		}
		//
		temp1 = "\r\nDSFID:";
		temp+=temp1;
		temp1.Format(" %02X",pBuf[18]);
		temp+=temp1;
		//
		temp1 = "\r\nAFI:";
		temp+=temp1;
		temp1.Format(" %02X",pBuf[19]);
		temp+=temp1;
		//
		temp1 = "\r\nCard Memory size:";
		temp+=temp1;
		temp1.Format(" %02X",pBuf[20]);
		temp+=temp1;
		temp1.Format(" %02X",pBuf[21]);
		temp+=temp1;
		//	
		temp1 = "\r\nIC infor:";
		temp+=temp1;
		temp1.Format(" %02X",pBuf[22]);
		temp+=temp1;
		//		
	}
	else
	{
		temp = "\r\n^----------------------------------------------------\r\nFail!";
	}
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);		
}

void CDlg4::OnBnClickedButton19()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048];
	unsigned char pBuf1[2048];
	unsigned short relen;
	int ret,strSize,strSize1;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	(GetDlgItem(IDC_EDIT6))->GetWindowText(m_V_edit15693uid);
	strcpy((char *)pBuf1,m_V_edit15693uid);
	CPublic::OXStrtoD(strSize1,pBuf1);
	//
	if(strSize1<8)
	{
		temp = "\r\n^----------------------------------------------------\r\nUID must be In 8Bytes!";
	}
	else
	{
		memcpy((unsigned char *)UID15693,pBuf1,8);
		(GetDlgItem(IDC_EDIT5))->SetWindowText("22");
		pBuf[0] = 0x22;
		//
		ret = ISO15693_Select(pBuf[0],&pBuf1[0],&relen,&pBuf[10]);
		if((ret==OK)&&(pBuf[10]==0))
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nSelect One Card OK";
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	//
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}

void CDlg4::OnBnClickedButton20()
{
	// TODO: �ڴ����ӿؼ�֪ͨ�����������
	unsigned char pBuf[2048];
	unsigned char pBuf1[2048];
	unsigned short relen;
	int ret,strSize,strSize1;
	CString neirong,temp,temp1;
	//
	(GetDlgItem(IDC_EDIT5))->GetWindowText(m_V_editflag);
	strcpy((char *)pBuf,m_V_editflag);
	CPublic::OXStrtoD(strSize,pBuf);
	//
	(GetDlgItem(IDC_EDIT6))->GetWindowText(m_V_edit15693uid);
	strcpy((char *)pBuf1,m_V_edit15693uid);
	CPublic::OXStrtoD(strSize1,pBuf1);
	//
	if(strSize1<8)
	{
		temp = "\r\n^----------------------------------------------------\r\nUID must be In 8Bytes!";
	}
	else
	{
		memset((unsigned char *)UID15693,0x00,8);
		(GetDlgItem(IDC_EDIT5))->SetWindowText("22");
		(GetDlgItem(IDC_EDIT6))->SetWindowText("");
		pBuf[0] = 0x22;
		//
		ret = ISO15693_Stay_Quiet(pBuf[0],&pBuf1[0],&relen,&pBuf[10]);
		if(ret==OK)
		{
			temp = "\r\n^----------------------------------------------------\r\nSuccessed!";
			temp1 = "\r\nStay Quiet This Card OK!\r\n";
			temp+=temp1;
			temp1 = "\r\nPlease Do A Select To Operate The Next Card!\r\n";
			temp+=temp1;
		}
		else
		{
			temp = "\r\n^----------------------------------------------------\r\nFail!";
		}
	}
	//
	GetDlgItemText(IDC_EDIT1,neirong); //��ȡ�ı��༭�����������
	SetDlgItemText(IDC_EDIT1,"\r\n");
	SetDlgItemText(IDC_EDIT1,temp+"\r\n"+neirong);	
}
